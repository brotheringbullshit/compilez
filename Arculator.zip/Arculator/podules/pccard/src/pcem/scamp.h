void scamp_init(void);
void scamp_reset(void);
