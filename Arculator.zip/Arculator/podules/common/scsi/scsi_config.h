void scsi_config_init(const podule_callbacks_t *callbacks);

extern podule_config_t scsi_podule_config;
