net_t *pcap_net_init(const char *network_device, uint8_t *mac_addr);
int pcap_net_get_devs(podule_config_selection_t *config, int max_devs);
