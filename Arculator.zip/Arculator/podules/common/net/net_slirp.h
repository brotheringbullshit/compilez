net_t *slirp_net_init(void);
