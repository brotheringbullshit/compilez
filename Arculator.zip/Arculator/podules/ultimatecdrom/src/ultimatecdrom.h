void cdlog(const char *format, ...);
void cdfatal(const char *format, ...);
