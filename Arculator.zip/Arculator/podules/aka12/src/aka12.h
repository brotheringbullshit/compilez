void aka12_log(const char *format, ...);

void aka12_set_irq(void *p);
void aka12_clear_irq(void *p);

void aka12_midi_send(void *p, uint8_t val);
